#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>

/*///////////////////////////////////////////////////////////////////////
||                                                                      ||
||                        OUSSAMA DRIOUICH                              ||
||                       GROUP : G2B                                    ||
||                      SMI4                                            ||
||                     CNE :20-G131663719                               ||
||                    2021-2022                                         ||
||                                                                      ||
||//////////////////////////////////////////////////////////////////////*/
/*
void MenuPrincipal(void);
//////////VOITURE //////
void MGVoiture(void);
void listevoiture(void);
void ajoutevoiture(void);
void modifiervoiture(void);
void supprimervoiture(void);
void Retourn(void);
int  checkid1(int);
int date_a_jour(struct date);
////////////CLIENTS///////
void MGClient(void);
void listeclient(void);
void ajouteclient(void);
void modifierclient(void);
void supprimeclient(void);
int checkid2(int);
int verifier2(char,char);
/////////////LOCATION///////
void MGlocation(void);
void Visualisercontrat(void);
void louervoiture(void);
void Retournervoiture(void);
void Modifiercontrat(void);
void Supprimercontrat(void);
int cout(int);
int checkid3(int);
void ajoutecontrat(void);
void enlocationsupp(int);
*/

struct date
{
     int dd,mm,yy;
};
typedef struct voiture
{
int idVoiture;
char marque[15];
char nomVoiture[15];
char couleur[7];
int nbplaces;
int prixJour;
char EnLocation[4];
} voiture;


typedef struct contrat
{
int numContrat;
int idVoiture;
int idClient;
struct date debut;
struct date fin;
int dure;
int cout;
} contrat;

typedef struct client
{
   int idClient;
   char nom[20];
   char prenom[20];
   int cin;
   char adresse[15];
   int telephone;
}client;
 struct voiture v;
 struct client cl;
 struct contrat co;


FILE *fp,*ft,*fs,*fts,*fc,*ftc;

/////////////////////////////////MENU PRINCIPALE ////////////////////////
void MenuPrincipal(void)
{  system("cls");
	int choix;


	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Menu Principale \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

	printf("\n\n");

	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    Location..............................1   \xba");
	printf("\n               \xba    Gestion voitures......................2   \xba");
	printf("\n               \xba    Gestion clients.......................3   \xba");
	printf("\n               \xba    Quitter...............................4   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");

 switch(getch())
{
     case '1':
         MenuLocation();
             break;
     case '2':
          MenuGestionVoiture();
             break;
     case '3':
         MenuGestionClient();
             break;
     case '4':{
	 system("cls");
             exit(0);}
     default:{

     	          printf("\n \n                 .............Choix Invalid ! ....................");

             if(getch())
                    MenuPrincipal();
             }
}
 }

/////////////////////////////////////// MENU GESTION CLIENT    ///////////////////////////////////////////
void MenuGestionClient(void)
{
	int choix;
	system("cls");

	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Gestion client  \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

	printf("\n\n");

	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    liset client..........................1   \xba");
	printf("\n               \xba    ajoute client.........................2   \xba");
	printf("\n               \xba    Modifier client ......................3   \xba");
	printf("\n               \xba    Supprimer client  ....................4   \xba");
	printf("\n               \xba    Retour................................5   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");

  switch(getch())
{
     case '1':
         listeclient();
             break;
     case '2':
          ajouteclient();
             break;
     case '3':
         modifierclient();
             break;
     case '4':
          supprimeclient();
             break;
     case '5':
        Retourn();
             break;
     default:{
      printf("\a.............Choix Invalid ! .....................");
             if(getch())
                    MenuGestionClient();
             }
}
}
/////////////////////////////////////   GESTION DE CLIENT  //////////////////////////////////////////////////
///////////////// CHECK ID ////////////////////

int checkid2(int s){
	rewind(fs);
	while(fread(&cl,sizeof(cl),1,fs)==1)

	if(cl.idClient==s)
	return 0;
	return 1;
   }
////////////////////////////// RETOURNER //////////////////////////
void Retourn(){
	printf("  \n\n\n************revenir au menu principal oui(o)/non(n) *******************\n\n\n");
        if(getch()=='o') {
            MenuPrincipal();}

}

//////////////////// 	AFFICHAGE DE CLIENT /////////////////////////////

void listeclient(void){
	system("cls");

char res;
    int d1;
      printf("\n********************************* Liste de clients *****************************\n");
	  fs=fopen("client.dat","rb");
       while(fread(&cl,sizeof(cl),1,fs)==1)
		{
				printf("\n id de client :   %d",cl.idClient);

			printf(" \n  nom de client : %s",cl.nom);

			printf(" \n  prenom de client :   %s",cl.prenom);

			printf(" \n  le cin de client:   %d",cl.cin);

			printf(" \n adresse de client :   %s",cl.adresse);

			printf("   \n   le telephone de client :  %d",cl.telephone);
          printf("\n ******************************************************************************\n");


            }  fclose(fs);
            
            printf(" \n\n	vouler-vous continue ? oui(o)/non(n): ");
            scanf("%c",&res);
            if(res=='O'||res=='o') {
            system("cls");
            MenuGestionClient();
			             
	
			}
		else{
		}
             system("cls");
        MenuPrincipal();
        
}


//////////////////// 	AJOUT DE CLIENT /////////////////////////////
void ajouteclient(void){
	system("cls");
     int d;
   printf("\n\n\n*************taper ID de client qui vous voulez ajouter: ");
   scanf("%d",&d);
    fs=fopen("client.dat","ab+");
	if(checkid2(d) == 0){
        printf("\a  ...........ID  client existe deja ................\a");
        sleep(4);
          	MenuGestionClient();}

    else{
           system("cls");

		          puts("\n**************************************************************************************************");
	            
                     cl.idClient=d;
					 printf("\n\t taper votre nom de client \n");
		             scanf("%s",cl.nom);
					 printf("\t taper votre de prenom de client  \n");
                     scanf("%s",cl.prenom);
                    printf("\t taper votre cin de client  \n");
                     scanf("%d",&cl.cin);
                    printf("\t taper votre telephone de client   \n");
                     scanf("%d",&cl.telephone);
                    printf("\t taper adresse de client\n ");
                     scanf("%s",cl.adresse);
          puts("\n**************************************************************************************************");
	        fwrite(&cl,sizeof(cl),1,fs);
	        fseek(fs,0,SEEK_END);
              fclose(fs);
                  printf("\n ---------------client a ete  ajoute avec succes --------------------");
                sleep(2);
            printf("\n------------- Ajouter un autre Client ? (o/n) : ");
               if(getch()=='n')
             MenuGestionClient();
               else
                 system("cls");
                 ajouteclient();
	}
}
///////////////////////////// MODIFIER CLIENT //////////////////////////
void  modifierclient(void){
	system("cls");
		int c=0;
		int d,e;

		printf("**\n\n\n***************Modifier la section des clients**********\n\n\n**");
		char another='o';
		while(another=='o')
		{
			system("cls");

			printf("***    taper le ID  de client qui vous modifier: ");
			scanf("%d",&d)
			;
			fs=fopen("client.dat","rb+");
			while(fread(&cl,sizeof(cl),1,fs)==1)
			{
				if(checkid2(d)==0)
				{

					printf("\n\n\n............ le cient est disponible  .................\n");

				cl.idClient=d;

					printf("\n taper nouveau nom de client :\n");scanf("%s",cl.nom);

					printf("\n taper nouveau prenom de client: \n");scanf("%s",cl.prenom);

					printf("\n  taper nouveau CIN de client : \n");scanf("%d",&cl.cin);

					printf("\ntaper nouveau adresss de client:\n");scanf("%s",cl.adresse);

					printf("\nEnter  nouveau telephone de client :\n");scanf("%d",&cl.telephone);

					printf("\n---------------------- Modification succed -----------------");
					fseek(fs,ftell(fs)-sizeof(cl),0);
					fwrite(&cl,sizeof(cl),1,fs);
					fclose(fs);
					c=1;

				}
				if(c==0)
				{

					printf("\n---------ERRUR D'ENREGSTREMNT----------------");
				}
			}

			printf("\n -------------- DO YOU WANT TO CONTINUE? oui(o)/non(n) ----------------  ");
			fflush(stdin);
			another=getch() ;
		}
	MenuGestionClient();
}
//////////////////////////////////: SUPPRIMER CLIENT ///////////////////////////
void supprimeclient(){
	char res;
	system("cls");
	int h;
	int y=0;
	printf("**************************************************************************************");
	 printf("           \n\n taper ID de client qui vous voulez supprimer  \n\n          ");
	  scanf("\t%d",&h);
	         fs=fopen("client.dat","rb+");
             rewind(fs);
             while(fread(&cl,sizeof(cl),1,fs)==1){
	 	        if(checkid2(h)==0){
	 		     printf("\n\\t\t ................ le client est disponible ...................\t\t");
			        printf("\n\t\t.................Voulez-vous le supprimer?(o/n) : ..................\t\n\t");
                                    if(getch()=='o'){
                            fts=fopen("test2.dat","wb+");
                              rewind(fs);
                                  while(fread(&cl,sizeof(cl),1,fs)==1){
                                         if(cl.idClient!=h){
                                        fseek(fts,0,SEEK_CUR);
                                         fwrite(&cl,sizeof(cl),1,fts);
                                     }                            }
                                          fclose(fts);
                                          fclose(fs);
                                           remove("client.dat");
                               rename("test2.dat","client.dat");
		                    	y++;
	 		                  printf("\n---------------- Client suppression succeded-------------------------");
	 		 }                    }            sleep(0);

	 		 if(y==0){
	           	printf("  \n ------ ID de votr client n'existe pas dans la liste ----------------- ");
			  }
           } 
           
           /*
		   printf("\n------------voulez-vous continue ? oui(o)/non(n)");
		   scanf("%c",&res);
		   if(res=='o'||res=='O'){
		   	system("cls");
		   	MenuGestionClient();
		   }
		   else{
		   	
		   			   	system("cls");
		   			   MenuPrincipal();	

		   	
		   }*/
	 }
///////////////////////////////////////////// MENU    GESTION VOITURE             /////////////////////////////////////////////

void MenuGestionVoiture()
{
	int choix;
    system("cls");

	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Gestion voiture \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

	printf("\n\n");

	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    liste de voiture......................1   \xba");
	printf("\n               \xba    Ajouter voiture.......................2   \xba");
	printf("\n               \xba    Modifier voiture......................3   \xba");
	printf("\n               \xba    Supprimer voiture.....................4   \xba");
	printf("\n               \xba    Retour................................5   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");


	 switch(getch())
{
     case '1':
          listevoiture();
             break;
     case '2':
          ajoutevoiture();
             break;
     case '3':
          modifiervoiture();
             break;
     case '4':
          supprimervoiture();
             break;
     case '5':
         Retourn();
             break;
     default:{
     	if(choix>5){
     	 printf("\a.............Choix Invalid ! .....................");
             if(getch())
                    MenuGestionVoiture();
             }	}

}
}
////////////////////// LIST CAR ///////////////////////
void listevoiture(void){
system("cls");
    int d;
      printf("\n\n********************************* Liste de voitures*****************************\n\n");
	  fp=fopen("voiture.dat","rb");
       while(fread(&v,sizeof(v),1,fp)==1)
		{
			printf("\n id de voiture :   %d",v.idVoiture);

			printf(" \n  marque de voiture : %s",v.marque);

			printf(" \n  le nom de voiture :   %s",v.nomVoiture);

			printf(" \n  le prix de joure de voiture :   %d",v.prixJour);

			printf(" \nle couleur de voiture:   %s",v.couleur);

			printf("   \n    le nembre deplace de voiture:  %d",v.nbplaces);

			printf("\n     en location  : oui /non    %s     \n",v.EnLocation);

			printf("****************************************************************************************");

            }  fclose(fp);
			printf(" \n	vouler-vous continue ? oui(o)/non(n)");
            if(getch()=='o') {
            system("cls");
            MenuGestionVoiture();
			}else{
             system("cls");
        MenuPrincipal();}
}
/////////////////////// AJOUT CAR ////////////////////
void  ajoutevoiture(void){
system("cls");

 int d;
   printf("\ntaper ID de voiture qui vous voulez ajouter :	");
   scanf("%d",&d);
    fp=fopen("voiture.dat","ab+");
	if(checkid1(d) == 0){
        printf("\aL'identifiant du voiture existe deja \a");

           MenuGestionVoiture();}//retourner a la menu voiture

    else{

           system("cls");
		          puts("/n**************************************************************************************************");
	            	printf("\n\ntaper votre nom de voiture \n");
		             scanf("%s",v.nomVoiture);
		            //printf("\ntaper votre Id de voiture \n");
                     v.idVoiture=d;
                    printf("\ntaper votre de mark de voiture  \n");
                     scanf("%s",v.marque);
                    printf("\ntaper votre couleur de voiture  \n");
                     scanf("%s",v.couleur);
                    printf("\ntaper votre nbplace de voiture  \n");
                     scanf("%d",&v.nbplaces);
                    printf("\ntaper votre prix de jour   \n");
                     scanf("%d",&v.prixJour);
                    printf("\n\ntaper votre enlocation oui /non \n ");
                     scanf("%s",v.EnLocation);

	        fwrite(&v,sizeof(v),1,fp);
	        fseek(fp,0,SEEK_END);
              fclose(fp);
                  printf("\n _____________Ajout  avec succes !_____________");

            printf("\n Ajouter une Autre Voiture	OUI(o)/NON(n)	");
               if(getch()=='o'||getch()=='O')
                 ajoutevoiture();
               else
			   MenuGestionVoiture();
                 system("cls");

	}
	}
///////////////////////// EDIT CAR ///////////////////

void modifiervoiture(void)
	{
		system("cls");
		int c=0;//teste la modefication a reusse
		int d;

		printf("**\n\n\nModifier la section des voitures\n\n\n**");
		char another='o';
		while(another=='o')
		{
			system("cls");

			printf("***taper le ID  de voiture qui vous modifieer:***");
			scanf("%d",&d);
			fp=fopen("Voiture.dat","rb+");
			while(fread(&v,sizeof(v),1,fp)==1)
			{
				if(checkid1(d)==0)
				{

					printf("\n\n\n le voiture est disponible");
                        v.idVoiture=d;
					//printf("\n nouveau  ID de voiture :%d",v.idVoiture);

					printf("\n nouveau  marque de voiture :");scanf("%s",v.marque);

					printf("\n  nouveau nom de voiture: ");scanf("%s",v.nomVoiture);

					printf("\ntaper nouveau couleur de voiture couleur:");scanf("%s",v.couleur);

					printf("\n nouveau prix de jour  voiture :");scanf("%d",&v.prixJour);

					printf("\nEnter  nouveau  nombre places:");scanf("%d",&v.nbplaces);
					printf("\nEnter  nouveau  en locale oui /non :");scanf("%v",v.EnLocation);
					printf("\n  modification avec sucess");
					fseek(fp,ftell(fp)-sizeof(v),0);
					fwrite(&v,sizeof(v),1,fp);
					fclose(fp);
					c=1;

				}
				if(c==0)
				{

					printf("Aucun Enregistrement Trouvee");
				}
			}

			printf("\nModifier un autre enregistrement?(o/n) ");
			fflush(stdin);
			another=getch() ;
		}
	  MenuGestionVoiture();
	}



////////////////////////// DELETE CAR ///////////////
void supprimervoiture(void){

	int h;
	int y=0;//test de existance de voiture
	printf("**************************************************************************************");
	 printf("           \n\n taper id de voiture qui vous voulez supprimer  \n\n          ");
	  scanf("%d",&h);
	         fp=fopen("voiture.dat","rb+");
             rewind(fp);
             while(fread(&v,sizeof(v),1,fp)==1){
	 	        if(checkid1(h)==0){
	 		     printf("\n\\t\t.........le voiture est disponible :)...........\t\t");
			        printf("\n\t\tVoulez-vous le supprimer?(o/n):\t\n\t");
                                    if(getch()=='o'){
                            ft=fopen("test.dat","wb+");  //temporary file for delete
                              rewind(fp);
                                  while(fread(&v,sizeof(v),1,fp)==1){
                                         if(v.idVoiture!=h){
                                        fseek(ft,0,SEEK_CUR);
                                         fwrite(&v,sizeof(v),1,ft); //write all in tempory file except that
                                     }                            }  //we want to delete
                                          fclose(ft);
                                          fclose(fp);
                                           remove("voiture.dat");
                               rename("test.dat","voiture.dat"); //copy all item from temporary file to fp except that
			y++;
	 		printf("\n              L'enregistrement est supprimer avec succes              ");
	 		 }}
	 		 if(y==0){

	           	printf("  \n				 ID de votr voiture n'existe pas dans la liste 									");

	      sleep(3);
		  	MenuGestionVoiture();
			  }
}
sleep(5);
 MenuGestionVoiture();
}


//////////////////// CHECK ID CAR //////////////////
int checkid1(int t)
{
rewind(fp);
while(fread(&v,sizeof(v),1,fp)==1)
if(v.idVoiture==t)
return 0;  //returns 0 if  exits
return 1; //return 1 if it not
}
////////////////////////////////////////////////////////////: LOCATION ////////////////////////////////////////////////

void MenuLocation()
{
	int choix;
	system("cls");


	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Location voiture\xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");

	printf("\n\n");

	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    Visualiser contrat....................1   \xba");
	printf("\n               \xba    louer voiture.........................2   \xba");
	printf("\n               \xba    Retourner voiture.....................3   \xba");
	printf("\n               \xba    Modifier contrat......................4   \xba");
	printf("\n               \xba    Supprimer contrat.....................5   \xba");
	printf("\n               \xba    Retour................................6   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");

switch(getch())
{
     case '1':
         Visualisercontrat();
             break;
     case '2':
          louervoiture();
             break;
     case '3':
         Retournervoiture();
             break;
     case '4':
          Modifiercontrat();
             break;
     case '5':
         Supprimercontrat();
             break;
     case '6':
         MenuPrincipal();
             break;
     default:{
      printf("\a.............Choix Invalid ! .....................");
             if(getch())
                    MenuLocation();
             }
}
}

//////////////////////// VISUALISER CONTRAT /////////////////////
void Visualisercontrat(void){

	 system("cls");
    int d,h=0;

    printf("\n ........... taper numero de contrat ...................\n");
    scanf("%d",&d);
    if(checkid3(d)==0){
	     fc=fopen("contrat.dat","rb");
     while(fread(&co,sizeof(co),1,fc)==1)
		{
		 printf("\n\n********************************* Liste de contrat*****************************\n\n");
              	printf("\n\tID de voiture        : %d\n",co.idVoiture);

	            printf("\t ID de client       : %d\n",co.idClient);

	            printf("\t le debut de la date  : %d/%d/%d\n",co.debut.dd,co.debut.mm,co.debut.yy);
	            printf("\t la fin de la date : %d/%d/%d\n",co.fin.dd,co.fin.mm,co.fin.yy);
	            printf("    	%d DH",co.cout);
	     printf("\n******************************************************************************\n");
        }fclose(fc); h=1;
        MenuLocation();
	}
    if(checkid3(d)==1){
    	printf(" \n\n ............ ce contrat n existe pas dans la liste .........\n");
    	
	}
	printf("\n\n	vouler-vous continue ? oui(o)/non(n)");
            if(getch()=='o') {
            system("cls");
            MenuLocation();
            
			    fclose(fc);
	
			}
		else{
	
             system("cls");
        MenuPrincipal();
	}
	
}
/////////////////////// LOUER VOITURE //////////////////////////

void louervoiture()
{
	int id,aide=0,aide1=0,aide2=0;
	char N[20],P[20],mar[15],nom[15];
	char R[4]="non",S[4]="oui";
	printf(" \n donner votre nom : \t");
	scanf("%s",N);
	printf("\n donner votre prenom: \t");
	scanf("%s",P);
	fc=fopen("client.dat","rb+");
	while(fread(&cl,sizeof(cl),1,fc)==1){
		if(strcmp(cl.nom,N)==0 && strcmp(cl.prenom,P)==0)
		{
			printf("\n\t.................client exist!!!................");
	
	
				printf("\n donner  nom de voiture: \t");
				scanf("%s",nom);
				printf("\n donner marque de voiture: \t");
				scanf("%s",mar);
			FILE *fv=fopen("voiture.dat","rb+");
			while(fread(&v,sizeof(v),1,fv)==1)
			{
				if(strcmp(v.marque,mar)==0 && strcmp(v.nomVoiture,nom)==0)
				{
					if(strcmp(v.EnLocation,R)==0)
					{   aide2=1;
						printf("\n \n \t la voiture choisi est disponible: ");
						printf("\n\n ..........louer cette voiture??? (non(n) / oui(o)) : ");
						if(getch()=='o')
						{
				{

				     printf("\n changer la valeur de (en location) de non a oui : ");scanf("%s",v.EnLocation);
					fseek(fv,ftell(fv)-sizeof(v),0);
					fwrite(&v,sizeof(v),1,fv);
					fclose(fv);
				}
							FILE *fcontrat=fopen("contrat.dat","ab+");
							printf(" \n\t donne un numero a cette contrat : ");
							scanf("%f",&co.numContrat);
							co.idVoiture=v.idVoiture;
							co.idClient=cl.idClient;
							printf("\n date de debut : \n");
                    			scanf("%d/%d/%d",&co.debut.dd,&co.debut.mm,&co.debut.yy);
                    			fflush(stdin);
                    			printf("\n date de fin : \n");
                     			scanf("%d/%d/%d",&co.fin.dd,&co.fin.mm,&co.fin.yy);
                     			fflush(stdin);
                     			co.cout=v.prixJour*((co.fin.dd+30*co.fin.mm+365*co.fin.yy)-(co.debut.dd+30*co.debut.mm+365*co.debut.yy));

	      				     fseek(fcontrat,0,SEEK_END);
                     			fwrite(&co,sizeof(co),1,fcontrat);fclose(fcontrat);
                     			printf("\n\n ---------saved successfully..............");
                     			sleep(3);
                     			MenuLocation();
					    }
					    else{
					    	MenuPrincipal();
					    	break;
						}
					}
					if(aide2==0){
						printf("\n ---------la voiture est deja louee par quelqun ....!!");
						printf("\n choisi une autre voiture : ");
						sleep(3);
						listevoiture();
	          		} aide1=1;
        	    }
			}fclose(fv);
			if(aide1==0){
				    printf("\n\n..........voiture nexiste pas !!.............");
				    sleep(3);
				  listevoiture();
			    }
				aide=1;
		   }
		}fclose(fc);
	if(aide==0){
			printf(" \n\n...........nom nexiste pas............!!! ");
			sleep(3);
			listeclient();
	}
}

//////////////////////// RETOURNER VOITURE ////////////////////
void Retournervoiture(void){
    system("cls");

	 	int id_voiture, id_client, num;
	 	int test=0;

	 	FILE*fcl=fopen("client.dat","rb+");
		FILE *fv=fopen("voiture.dat","rb+");
	 	FILE*fco=fopen("contrat.dat","rb+");
	 	printf("	** Retour de voiture **");
	 	printf("\n	=> Entrer l'id de voiture a retourner : ");
	 	scanf("%d",&id_voiture);

	 	if( v.idVoiture == id_voiture ){

	 		printf("\n	=> Entrer votre id de client  : ");
	 		scanf("%d",&id_client);
	 		if( cl.idClient == id_client){

	 			printf("\n	=> Entrer num de votre contrat : ");
	 			scanf("%d",&num);
	 			if( co.numContrat == num  ){

	 				 printf(" changer la valeur de en locatio de oui a non : ");scanf("%s",v.EnLocation);
					fseek(fv,ftell(fv)-sizeof(v),0);
					fwrite(&v,sizeof(v),1,fv);	
					fclose(fv);
						Supprimercontrat();
	 			}else{
			 		printf("	==> Num de contrat n'existe pas! ");
			 		printf("	Ressayer a nouveau (O/N)? ");
			 		if(getch()=='O') Retournervoiture();
				 }

	 		}else{
		 		printf("	==> Id n'existe pas! ");
		 		printf("	Ressayer a nouveau (O/N)? ");
		 		if(getch()=='O') Retournervoiture();
			 }

		 }else{
		 	printf("	==> Id n'existe pas! ");
		 	printf("	Ressayer a nouveau (O/N)? ");
		 	if(getch()=='O') Retournervoiture();
		 }
		 fclose(fc);
		 fclose(fp);
		 fclose(fs);
}

//////////////////////// MODIFIER CONTRAT ////////////////////
void Modifiercontrat(void){
		system("cls");
		int n=0;
		int d,e;

		printf("**\n\n\n***************Modifier la section des contrats**********\n\n\n**");
		char another='o';
		while(another=='o')
		{
			system("cls");

			printf("***taper le numero de contrat qui vous modifieer:***");
			scanf("%d",&d)
			;
			FILE *fco=fopen("contrat.dat","rb+");
			while(fread(&co,sizeof(co),1,fc)==1)
			{
				if(checkid3(d)==0)
				{

					printf("\n\n\n............ le contrat est disponible :) .................\n");

					printf("\n taper nouveau date de dubet  jj/mm/yy:\n");scanf("%d%d%d",&co.debut.dd,&co.debut.mm,&co.debut.yy);
						fflush(stdin);
					printf("\n taper nouveau date de fin jj/mm/yy:\n");scanf("%d%d%d",&co.fin.dd,&co.fin.mm,&co.fin.yy);
						fflush(stdin);

					printf("\n  nouveau  cout : (prix par jour * la duree)");scanf("%d",&co.cout);
											fflush(stdin);

					fseek(fco,ftell(fco)-sizeof(co),0);
					fwrite(&co,sizeof(co),1,fco);
					fclose(fco);
					printf("\n ----------la nouveau date est changee---------------------");
					//fseek(fc,ftell(fc)-sizeof(co),0);
					//fwrite(&co,sizeof(co),1,fc);
					//fclose(fc);
					n=1;

				}
				if(n==0)
				{

					printf("\n---------------------------contrat dosen't exist-------------------");
				}
			}

			printf("\n *****************Modifier un autre enregistrement?(o/n) *************************8");
			fflush(stdin);
			another=getch() ;
		}

	MenuLocation();
}


///////////////////////// SUPPRIMER CONTRAT /////////////////

void Supprimercontrat(void){
	system("cls");
	int h;
	int y=0;
	printf("**************************************************************************************");
	 printf("           \n\n taper nemro de contrat qui vous voulez supprimer  \n\n          ");
	  scanf("%d",&h);
	         fc=fopen("contrat.dat","rb+");
             rewind(fc);
             while(fread(&co,sizeof(co),1,fc)==1){
	 	        if(checkid3(h)==0){
	 		     printf("\n\\t\t ................ le contrat est disponible :)...................\t\t");
			        printf("\n\t\t.................Voulez-vous le supprimer?(o/n) : ..................\t\n\t");
                                    if(getch()=='o'){
                            ftc=fopen("test2.dat","wb+");
                              rewind(fc);
                                  while(fread(&co,sizeof(co),1,fc)==1){
                                         if(co.numContrat!=h){
                                        fseek(ftc,0,SEEK_CUR);
                                         fwrite(&co,sizeof(co),1,ftc);
                                     }                            }
                                          fclose(ftc);
                                          fclose(fc);
                                           remove("contrat.dat");
                               rename("test3.dat","contrat.dat");
			y++;
	 		printf("\n			 Le Contrat est supprimer avec succes 			");
	 		 }} sleep(5);
	 		 if(y==0){
	           	printf("  \n        le contrat  n'existe pas dans le programe :) \a  \n          ");
			  }
           }system("cls");

	MenuLocation();}

////////////////
int checkid3(int d){
	rewind(fc);
	while(fread(&co,sizeof(co),1,fc)==1);

	if(co.numContrat==d)
	return 0;
	return 1;
   }
   
   
   /////////////////:MAIN:///////////////////////////////////

int main() {
	MenuPrincipal();
	getch();
	return 0;
}
///////////////////////////////////////// FIN ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
